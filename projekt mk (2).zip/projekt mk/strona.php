<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Komis Motocyklowy</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header>
        <h1>Komis Motocyklowy</h1>
        <p>Najlepsze motocykle w najniższej cenie!</p>


    
            <a href="login.php">Zaloguj się</a> | <a href="register.php">Zarejestruj się</a>
        <?php endif; ?>
    </header>

    <nav>
        <ul>
            <li><a href="#about">O nas</a></li>
            <li><a href="#motorcycles">Oferty Motocykli</a></li>
            <li><a href="#services">Usługi</a></li>
            <li><a href="#contact">Kontakt</a></li>
            <li><a href="#info">Informacje o działalności komisu</a></li>
        </ul>
    </nav>

    <section id="filters">
        <h2>Filtruj oferty</h2>
        <form id="filterForm">
            <label for="brand">Marka:</label>
            <select id="brand" name="brand">
                <option value="">Wybierz markę</option>
                <option value="Yamaha">Yamaha</option>
                <option value="Honda">Honda</option>
                <option value="Kawasaki">Kawasaki</option>
            </select>

            <label for="type">Typ:</label>
            <select id="type" name="type">
                <option value="">Wybierz typ</option>
                <option value="Sportowy">Sportowy</option>
                <option value="Turystyczny">Turystyczny</option>
                <option value="Cruiser">Cruiser</option>
            </select>

            <label for="price">Cena (do):</label>
            <input type="number" id="price" name="price" placeholder="Cena max.">

            <button type="button" id="filterButton">Filtruj</button>
        </form>
    </section>

    <section id="motorcycles">
        <h2>Oferty Motocykli</h2>
        <div class="motorcycle-list">
            <div class="motorcycle" data-brand="Yamaha" data-type="Sportowy" data-price="60000">
                <h3><a href="yamaha-r1.html">Yamaha R1</a></h3>
                <p>Rok produkcji: 2020</p>
                <p>Przebieg: 15,000 km</p>
                <p><strong>Cena:</strong> 60,000 PLN</p>
            </div>
            <div class="motorcycle" data-brand="Honda" data-type="Sportowy" data-price="35000">
                <h3><a href="honda-cbr600rr.html">Honda CBR 600RR</a></h3>
                <p>Rok produkcji: 2018</p>
                <p>Przebieg: 10,500 km</p>
                <p><strong>Cena:</strong> 35,000 PLN</p>
            </div>
            <div class="motorcycle" data-brand="Kawasaki" data-type="Turystyczny" data-price="45000">
                <h3><a href="kawasaki-ninja1000.html">Kawasaki Ninja 1000</a></h3>
                <p>Rok produkcji: 2022</p>
                <p>Przebieg: 3,000 km</p>
                <p><strong>Cena:</strong> 45,000 PLN</p>
            </div>
        </div>
    </section>

    <section id="services">
        <h2>Usługi</h2>
        <ul>
            <li>Sprzedaż motocykli nowych i używanych</li>
            <li>Serwis i naprawy</li>
            <li>Ubezpieczenia motocykli</li>
            <li>Porady techniczne</li>
        </ul>
    </section>

    <section id="info">
        <h2>Informacje o działalności komisu</h2>
        <p>Jesteśmy komis motocyklowy z wieloletnim doświadczeniem. Nasza oferta obejmuje motocykle wszystkich marek, które przeszły szczegółową weryfikację techniczną. Oferujemy również pomoc przy zakupie, doradztwo oraz pełną obsługę serwisową.</p>
    </section>

    <section id="about">
        <h2>O nas</h2>
        <p>Nasza firma istnieje na rynku od 15 lat i specjalizuje się w sprzedaży motocykli. Naszym celem jest zapewnienie najlepszych motocykli w atrakcyjnych cenach, przy zachowaniu wysokich standardów jakościowych i bezpieczeństwa.</p>
        <h3>Historia firmy</h3>
        <p>Firma została założona w 2005 roku przez pasjonatów motocykli. Od tego czasu rozwinęliśmy naszą działalność, oferując szeroką gamę motocykli oraz usług.</p>
        <h3>Informacje o zespole</h3>
        <p>Nasza drużyna to wykwalifikowani mechanicy, doradcy i eksperci w dziedzinie motocykli. Zawsze gotowi, by pomóc naszym klientom w wyborze idealnego motocykla.</p>
    </section>

    <section id="contact">
        <h2>Kontakt</h2>
        <p><strong>Telefon:</strong> +48 123 456 789</p>
        <p><strong>Email:</strong> kontakt@komismotocyklowy.pl</p>
        <p><strong>Adres:</strong> ul. Motocyklowa 12, 00-001 Warszawa</p>
        <p><strong>Imię i nazwisko:</strong> Mikołaj Kasperek</p>
    </section>

    <div id="cookie-notice">
        <p>Ta strona używa plików cookies w celu poprawy jakości usług. <button id="accept-cookies">Zgadzam się</button></p>
    </div>

</body>
</html>
