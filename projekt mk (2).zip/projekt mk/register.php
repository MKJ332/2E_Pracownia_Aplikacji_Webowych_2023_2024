<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); 
    $email = $_POST['email'];

  
    $sql_check = "SELECT * FROM users WHERE username='$username' OR email='$email'";
    $result_check = $conn->query($sql_check);
    
    if ($result_check->num_rows > 0) {
        echo "Użytkownik o podanej nazwie lub emailu już istnieje.";
    } else {
        $sql = "INSERT INTO users (username, password, email) VALUES ('$username', '$password', '$email')";
        
        if ($conn->query($sql) === TRUE) {
            echo "Rejestracja zakończona sukcesem! Możesz się teraz zalogować.";
        } else {
            echo "Błąd: " . $sql . "<br>" . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rejestracja - Komis Motocyklowy</title>
</head>
<body>
    <header>
        <h1>Rejestracja</h1>
    </header>

    <main>
        <form action="register.php" method="POST">
            <label for="username">Nazwa użytkownika:</label>
            <input type="text" name="username" id="username" required><br><br>

            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required><br><br>

            <label for="password">Hasło:</label>
            <input type="password" name="password" id="password" required><br><br>

            <button type="submit">Zarejestruj się</button>
        </form>
    </main>
</body>
</html>
