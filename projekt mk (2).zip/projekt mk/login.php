<?php
session_start();
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];


    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header("Location: index.php");
            exit();
        } else {
            echo "Nieprawidłowe hasło.";
        }
    } else {
        echo "Nie znaleziono użytkownika.";
    }
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie - Komis Motocyklowy</title>
</head>
<body>
    <header>
        <h1>Logowanie</h1>
    </header>

    <main>
        <form action="login.php" method="POST">
            <label for="username">Nazwa użytkownika:</label>
            <input type="text" name="username" id="username" required><br><br>

            <label for="password">Hasło:</label>
            <input type="password" name="password" id="password" required><br><br>

            <button type="submit">Zaloguj się</button>
        </form>
    </main>
</body>
</html>
