
document.getElementById("filterButton").addEventListener("click", function () {

    const brandFilter = document.getElementById("brand").value.toLowerCase();
    const typeFilter = document.getElementById("type").value.toLowerCase();
    const priceFilter = parseInt(document.getElementById("price").value, 10) || Infinity; 


    const motorcycles = document.querySelectorAll(".motorcycle");

    motorcycles.forEach(function (motorcycle) {
        
        const brand = motorcycle.getAttribute("data-brand").toLowerCase();
        const type = motorcycle.getAttribute("data-type").toLowerCase();
        const price = parseInt(motorcycle.getAttribute("data-price"), 10);

        
        const matchesBrand = brandFilter === "" || brand.includes(brandFilter);
        const matchesType = typeFilter === "" || type.includes(typeFilter);
        const matchesPrice = price <= priceFilter;

        
        if (matchesBrand && matchesType && matchesPrice) {
            motorcycle.style.display = "block";
        } else {
            motorcycle.style.display = "none";
        }
    });
});


document.getElementById("accept-cookies").addEventListener("click", function () {
   
    document.getElementById("cookie-notice").style.display = "none";
});
