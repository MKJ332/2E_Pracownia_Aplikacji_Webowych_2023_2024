<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'config.php';

    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); 

    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);

    if ($stmt->rowCount() > 0) {
        echo "Użytkownik o tym adresie e-mail już istnieje!";
    } else {
    
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        if ($stmt->execute([$username, $email, $password])) {
            echo "Rejestracja zakończona sukcesem!";
        } else {
            echo "Wystąpił problem przy rejestracji!";
        }
    }
}
?>

<form method="post" action="rejestracja.php">
    <label for="username">Nazwa użytkownika:</label>
    <input type="text" id="username" name="username" required><br><br>

    <label for="email">E-mail:</label>
    <input type="email" id="email" name="email" required><br><br>

    <label for="password">Hasło:</label>
    <input type="password" id="password" name="password" required><br><br>

    <button type="submit">Zarejestruj się</button>
</form>
