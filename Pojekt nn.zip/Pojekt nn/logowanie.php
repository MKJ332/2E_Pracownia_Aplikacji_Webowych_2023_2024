<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'config.php';

    $email = $_POST['email'];
    $password = $_POST['password'];

   
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);

    if ($stmt->rowCount() > 0) {
        $user = $stmt->fetch();
        if (password_verify($password, $user['password'])) {
         
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            echo "Zalogowano pomyślnie!";
        } else {
            echo "Nieprawidłowe hasło!";
        }
    } else {
        echo "Użytkownik o tym adresie e-mail nie istnieje!";
    }
}
?>

<form method="post" action="logowanie.php">
    <label for="email">E-mail:</label>
    <input type="email" id="email" name="email" required><br><br>

    <label for="password">Hasło:</label>
    <input type="password" id="password" name="password" required><br><br>

    <button type="submit">Zaloguj się</button>
</form>
